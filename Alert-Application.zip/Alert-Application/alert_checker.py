import imaplib
import email
from email.header import decode_header

def download_emails(user_email, password, sender_email):
    # create content str to record new emails
    content = str()
        
    # connect to the gmail IMAP server
    imap = imaplib.IMAP4_SSL("imap.gmail.com")

    # login to account
    try:
        imap.login(user_email, password)
    except imaplib.IMAP4.error as e:
        print("Login failed:", e)
        return

    # select inbox to search
    imap.select("inbox")

    # search for unread emails from the specific sender
    search_query = f'FROM "{sender_email}" UNSEEN'
    messages = imap.search(None, search_query)[1]

    # convert messages to a list of email IDs
    email_ids = messages[0].split()

    for email_id in email_ids:  # process all unread emails
        # fetch email by ID
        msg = imap.fetch(email_id, "(RFC822)")[1]
        for response in msg:
            if isinstance(response, tuple):
                # parse email
                msg = email.message_from_bytes(response[1])
                subject, encoding = decode_header(msg["Subject"])[0]
                if isinstance(subject, bytes):
                    # decode subject if it's in bytes
                    subject = subject.decode(encoding or "utf-8")
                from_ = msg.get("From")
                content += f"Subject: {subject}\n"
                content += f"From: {from_}\n"

                # get email body
                if msg.is_multipart():
                    for part in msg.walk():
                        content_type = part.get_content_type()
                        content_disposition = str(part.get("Content-Disposition"))
                        if content_type == "text/plain" and "attachment" not in content_disposition:
                            body = part.get_payload(decode=True).decode()
                            content += f"Body:\n{body}"
                            break
                else:
                    # if email is not multipart
                    body = msg.get_payload(decode=True).decode()
                    content += f"Body:\n{body}"

                content += "-" * 50
                content += "\n"

    # close connection and logout
    imap.close()
    imap.logout()

    return content