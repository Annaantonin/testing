import datetime

def save_emails(content):
    file_name = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    database = open(f"emails/{file_name}.txt", "w")
    database.write(content)
    database.close()