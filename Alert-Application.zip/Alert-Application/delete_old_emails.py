import os
import datetime
import glob

def delete_old_files(directory="./emails"):
    # get date one month ago
    one_month_ago = datetime.datetime.now() - datetime.timedelta(days=30)
    
    # find files in format "YEAR-MONTH-DAY HOUR-MINUTE-SECONDS.txt"
    file_pattern = os.path.join(directory, "*.txt")
    
    for file in glob.glob(file_pattern):
        try:
            # get the date time of the file
            file_datetime = datetime.datetime.strptime(os.path.basename(file)[:-4], "%Y-%m-%d %H:%M:%S")
            
            # remove file if older than one month
            if file_datetime < one_month_ago:
                os.remove(file)
                print(f"Deleted: {file}")
        except ValueError:
            # skip files that aren't in "YEAR-MONTH-DAY HOUR-MINUTE-SECONDS.txt" format
            print(f"Skipping: {file}")

if __name__ == "__main__":
    delete_old_files()