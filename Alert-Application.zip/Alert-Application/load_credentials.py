def load_credentials(credentials_file):
    file = open(credentials_file)
    credentials = (file.readline()[:-1], file.readline()[:-1], file.readline()[:-1])
    file.close()

    return credentials