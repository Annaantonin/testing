from datetime import datetime, timedelta
from flask import Flask, render_template_string
from apscheduler.schedulers.background import BackgroundScheduler
import load_credentials
import alert_checker
import record_email
import delete_old_emails

# initialize Flask app
app = Flask(__name__)

# create a list to store dots, and a variable to keep track of when the dots expire
dots = list()
expiration_time = None

# load credentials to check for emails, stored in bin
credentials = load_credentials.load_credentials("bin/login")

# store pixel positions of each location
locations = {
    # S.Relief
    "S_Relief_1__": (4242, 1466),
    "S_Relief_2__": (4218, 1443),
    "S_Relief_3__": (4204, 1377),
    "S_Relief_4__": (4204, 1292),
    "S_Relief_5__": (4204, 1122),
    "S_Relief_6__": (4204, 1025),
    "S_Relief_7__": (4204, 965),
    "S_Relief_8__": (4242, 920),
    "S_Relief_9__": (4242, 901),
    # N.Relief
    "N_Relief_1__": (4513, 1465),
    "N_Relief_2__": (4558, 1384),
    "N_Relief_3__": (4558, 1314),
    "N_Relief_4__": (4558, 1140),
    "N_Relief_5__": (4558, 1020),
    "N_Relief_6__": (4541, 938),
    "N_Relief_7__": (4511, 921),
    "N_Relief_8__": (4511, 907),
    # CL-17
    "Case_Bottom": (1725, 1502),
    # M13
    "Floor_Master": (2025, 1641),
    "Center_Qurans": (2025, 1667),
    "Left_Qurans": (2025, 1703),
    "Jali_screen": (2087, 1841),
    # M20
    "IranMeso_case": (2026, 1267),
    "Floor_Qurans": (2025, 1041),
    "Case_Qurans": (2025, 1050),
    "Beam_Qurans": (2025, 1059),
    # M9
    "Floor_Ceramics": (1966, 1047),
    "Shelf_corner": (1966, 1053),
    "Shelf_wall": (1893, 1050),
    # M7
    "Samarra_case_Bottom_shelf_": (2025, 961),
    "Samarra_case_Top_shelf_cor": (2032, 961),
    "Samarra_case_Top_shelf_end": (2039, 961),
    # M12
    "Floor": (2031, 832),
    "Pair_Doors": (2031, 840),
    "Capital": (2031, 851),
    "Pair_Doors_Carved": (2031, 861),
    # M4
    "Floor_reference": (2026, 677),
    "Small_panel": (2026, 680),
    "Big_panel": (2026, 683),
    "Nishapur_objects": (2026, 686),
    # M3
    "Bottom_shelf__": (1976, 895),
    "Middle_Shelf__": (1921, 895),
    "Top_shelf": (1897, 727),
    # W4
    "Armor case_": (2308, 2945),
    # CL18
    "MinoanSeals_case___": (4499, 2329),
    "GreekMarbles_case__": (4577, 2973),
    # CL19
    "Roof_fragm_": (2089, 3889)
}

def check_for_emails():
    """
    Check for new email alerts,
    and if there are any, display
    dots accordingly, different colors
    depending on severity of alerts
    """
    global dots, expiration_time, locations

    # download emails based on the credentials given (user email, password, sender email)
    content = alert_checker.download_emails(credentials[0], credentials[1], credentials[2]).strip()
    emails = None
    if content:
        record_email.save_emails(content)
        emails = content.split("-"*50)
    
    # if there are new alerts, parse through the alerts and add dots based on alert level, location
    x = None
    y = None
    color = None

    if emails:
        for message in emails:
            content = message.split("\n")
            for line in content:
                if "      " not in line or "Sensor_ID_in_Gallery" in line:
                    continue
                print(f"Alert Found at {line.split("      ")[0]}")
                print(f"Alert Triggered by Value {line.split("      ")[1]}mm/s")
                if float(line.split("      ")[1]) >= 3.0 and float(line.split("      ")[1]) < 5.0:
                    color = "orange"
                elif float(line.split("      ")[1]) >= 5.0:
                    color = "red"
                else:
                    continue

                for location in locations.keys():
                    if location in line.split("      ")[0]:
                        x, y = locations[location]
            
                dots.append({"x": x, "y": y, "color": color})
        
        # declare expiration time of 5 minutes for dots to expire
        expiration_time = datetime.now() + timedelta(minutes=5)

@app.route("/")
def index():
    global dots, expiration_time
    
    # if the dots have expired (lasted > 5min), clear them
    if expiration_time and datetime.now() > expiration_time:
        dots = list()
        expiration_time = None
    
    # display MET map and add dots accordingly
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            .image-container {
                position: relative;
                display: inline-block;
            }
            .dot {
                position: absolute;
                width: 50px;
                height: 50px;
                border-radius: 50%;
            }
        </style>
    </head>
    <body>
        <div class="image-container">
            <img src="{{ url_for('static', filename='images/MET-MAP.jpg') }}" alt="MET Map">
            {% for dot in dots %}
                <div class="dot" style="left: {{ dot.x }}px; top: {{ dot.y }}px; background-color: {{ dot.color }};"></div>
            {% endfor %}
        </div>
    </body>
    </html>
    """
    
    return render_template_string(html_content, dots=dots)

if __name__ == "__main__":
    # create a scheduler to check for new emails every second
    scheduler = BackgroundScheduler()
    # check for emails every 5 seconds
    scheduler.add_job(check_for_emails, 'interval', seconds=5)
    scheduler.add_job(delete_old_emails.delete_old_files, 'interval', seconds=5)
    scheduler.start()

    app.run(host='0.0.0.0', port=80)